from win32com.client import gencache
from win32com.client import constants, gencache
import os
 
 
def createPdf(wordPath, pdfPath):
    """
    word转pdf
    :param wordPath: word文件路径
    :param pdfPath:  生成pdf文件路径
    """
    word = gencache.EnsureDispatch('Word.Application')
    doc = word.Documents.Open(wordPath, ReadOnly=1)
    doc.ExportAsFixedFormat(pdfPath,
                            constants.wdExportFormatPDF,
                            Item=constants.wdExportDocumentWithMarkup,
                            CreateBookmarks=constants.wdExportCreateHeadingBookmarks)
    word.Quit(constants.wdDoNotSaveChanges)
 
#sourcePath="C:/Users/Administrator/Desktop/word"
sourcePath="D:\G\G\Linfox 启动器\word转pdf\新建文件夹"
files=os.listdir(sourcePath)
 
for file in files:
    file = sourcePath+'/'+file
 
    pdfpath=file+'.pdf'
    print(pdfpath)
    createPdf(file,pdfpath)